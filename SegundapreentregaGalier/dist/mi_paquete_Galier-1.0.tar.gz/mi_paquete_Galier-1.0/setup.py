from setuptools import setup 

setup(

    name="mi_paquete_Galier",
    version="1.0",
    description="Paquete de mi segunda preentrega y la primera tambien  ",
    author="Agustin Galier",
    author_email="agusstingalier@gmail.com",
    packages=["SegundapreentregaGalier.mi_paquete"]
)